"""svlang — Swedish NLP toolkit for translators."""

__version__ = "0.1.5"
